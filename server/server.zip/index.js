const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const POModel = require("./models/POModel"); // Updated model import

const app = express();
app.use(cors());
app.use(express.json());


const { MongoClient, ServerApiVersion } = require('mongodb');
const uri = "mongodb+srv://guravvedika17:<db_password>@cluster0.yjdwfxg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

async function run() {
  try {
    // Connect the client to the server	(optional starting in v4.7)
    await client.connect();
    // Send a ping to confirm a successful connection
    await client.db("admin").command({ ping: 1 });
    console.log("Pinged your deployment. You successfully connected to MongoDB!");
  } finally {
    // Ensures that the client will close when you finish/error
    await client.close();
  }
}
run().catch(console.dir);

// mongoose.connect("mongodb://127.0.0.1:27017/SupplierPOManagement", {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// })
// .then(() => console.log("MongoDB connected"))
// .catch((err) => console.log("MongoDB connection error:", err));

// Get all POs
app.get("/", (req, res) => {
  POModel.find()
    .then(pos => res.json(pos))
    .catch(err => res.json(err));
});

// Get single PO by ID
app.get("/getPO/:id", (req, res) => {
  const id = req.params.id;
  POModel.findById(id)
    .then(po => {
      if (!po) {
        return res.status(404).json({ error: "PO not found" });
      }
      res.json(po);
    })
    .catch(err => res.status(500).json({ error: "Error fetching PO", details: err }));
});

// Update PO by ID
app.put("/updatePO/:id", (req, res) => {
  const id = req.params.id;
  POModel.findByIdAndUpdate(id, req.body, { new: true })
    .then(updatedPO => res.json(updatedPO))
    .catch(err => res.status(500).json({ error: "Failed to update PO", details: err }));
});

// Delete PO by ID
app.delete('/deletePO/:id', (req, res) => {
  const id = req.params.id;
  POModel.findByIdAndDelete(id)
    .then(deletedPO => res.json(deletedPO))
    .catch(err => res.json(err));
});

// Create new PO
app.post("/createPO", (req, res) => {
  POModel.create(req.body)
    .then(po => res.json(po))
    .catch(err => res.status(500).json(err));
});

app.listen(3001, () => {
  console.log("server is running on port 3001");
});
